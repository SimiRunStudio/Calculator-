#include <jni.h>
#include <string>
#include <vector>
#include <sstream>
#include "sa_calculator.hpp"

static std::string jstr(JNIEnv* e, jstring s){ if(!s) return {}; const char* p=e->GetStringUTFChars(s,nullptr); std::string r=p?p:""; if(p)e->ReleaseStringUTFChars(s,p); return r; }
static jobjectArray makeStrings(JNIEnv* e,const std::vector<std::string>& v){
    jclass sc=e->FindClass("java/lang/String"); jobjectArray a=e->NewObjectArray((jsize)v.size(),sc,nullptr);
    for(size_t i=0;i<v.size();++i)e->SetObjectArrayElement(a,(jsize)i,e->NewStringUTF(v[i].c_str())); return a;
}
extern "C" JNIEXPORT jstring JNICALL Java_com_sacalculator_android_NativeBridge_run(JNIEnv* e,jclass,jstring tool,jobjectArray keys,jobjectArray values){
    sa::Inputs in; std::string t=jstr(e,tool); jsize n=keys?e->GetArrayLength(keys):0;
    for(jsize i=0;i<n;++i){ auto k=(jstring)e->GetObjectArrayElement(keys,i); auto v=(jstring)e->GetObjectArrayElement(values,i); in[jstr(e,k)]=jstr(e,v); e->DeleteLocalRef(k);e->DeleteLocalRef(v); }
    auto r=sa::CalculatorEngine::run(t,in); std::string out=(r.ok?"OK\n":"ERR\n")+(r.ok?r.text:r.error); return e->NewStringUTF(out.c_str());
}
extern "C" JNIEXPORT jobjectArray JNICALL Java_com_sacalculator_android_NativeBridge_registry(JNIEnv* e,jclass){
    std::vector<std::string> v; for(const auto&t:sa::CalculatorEngine::registry()) v.push_back(t.id+"|"+t.title+"|"+t.category); return makeStrings(e,v);
}
extern "C" JNIEXPORT jstring JNICALL Java_com_sacalculator_android_NativeBridge_graph(JNIEnv* e,jclass,jstring expr,jdouble xmin,jdouble xmax){
    std::vector<std::string> x{jstr(e,expr)}; auto r=sa::GraphEngine::sample(x,xmin,xmax,1200); std::string out=(r.ok?"OK\n":"ERR\n")+(r.ok?r.text:r.error); return e->NewStringUTF(out.c_str());
}
