#pragma once
#include <string>
#include <vector>
#include <map>
#include <optional>
#include <cstdint>
#include <memory>

namespace sa {
using Inputs = std::map<std::string,std::string>;
struct Result { bool ok=false; std::string text; std::string error; };
struct ToolInfo { std::string id,title,icon,category; };
struct HistoryItem { std::string tool,title,timestamp; Inputs inputs; std::string result; };

class CalculatorEngine {
public:
  static const std::vector<ToolInfo>& registry();
  static Result run(const std::string& tool, const Inputs& in);
  static std::string toolTitle(const std::string& id);
  static bool hasTool(const std::string& id);
};

class GraphEngine {
public:
  static Result sample(const std::vector<std::string>& expressions,double xmin,double xmax,int samples=1200);
};

class AppState {
public:
  std::vector<HistoryItem> history;
  std::vector<std::string> favorites;
  std::string lastTool;
  void addHistory(const HistoryItem& item);
  void toggleFavorite(const std::string& tool);
  bool isFavorite(const std::string& tool) const;
  bool save(const std::string& path) const;
  bool load(const std::string& path);
  void clearHistory();
};

class Exporter {
public:
  static std::string json(const HistoryItem& item);
  static std::string txt(const HistoryItem& item);
  static std::string csv(const HistoryItem& item);
  static bool write(const HistoryItem& item,const std::string& path,const std::string& format);
};

class NativeApp {
public:
  NativeApp();
  void printHome() const;
  void printTools() const;
  Result execute(const std::string& tool,const Inputs& inputs,bool record=true);
  bool exportLast(const std::string& format,const std::string& path) const;
  bool restoreLast();
  const std::optional<HistoryItem>& last() const;
  AppState& state();
private:
  AppState state_;
  std::optional<HistoryItem> last_;
};
}
