#!/usr/bin/env bash
set -euo pipefail
command -v gradle >/dev/null || { echo 'Gradle 9.5+ required. Android Studio can also open this project.'; exit 1; }
gradle --no-daemon :app:assembleDebug :app:assembleRelease
echo 'Debug: app/build/outputs/apk/debug/app-debug.apk'
echo 'Release: app/build/outputs/apk/release/app-release-unsigned.apk'
