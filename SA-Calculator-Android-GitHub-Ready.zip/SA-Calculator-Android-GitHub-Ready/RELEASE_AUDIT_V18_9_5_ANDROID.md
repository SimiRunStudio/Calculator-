# SA Calculator 18.9.5 Android Packaging Audit

## Verified in this environment

- Native C++17 calculator engine compiles with warnings enabled: PASS
- Native registry count: 28: PASS
- JavaScript files: 0
- HTML files: 0
- CSS files: 0
- WebView/DOM source: 0
- Desktop X11 code is excluded from the Android module
- Android module uses C++17 + JNI + Android native Java UI
- GitHub Actions workflow present
- Debug + release Gradle tasks configured
- NDK version pinned: 28.2.13676358
- CMake version pinned: 3.22.1
- AGP version pinned: 9.3.0
- Gradle CI version pinned: 9.5.0
- JDK CI version pinned: 17
- No signing secret is stored in the repository

## Not claimed here

A physical Android APK build/install was not executed in this Linux environment because the Android SDK/NDK toolchain is not installed here. The included GitHub Actions workflow performs the real Android build on GitHub's runner.
