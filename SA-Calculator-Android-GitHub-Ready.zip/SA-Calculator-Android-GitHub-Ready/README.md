# SA Calculator — Android / GitHub Ready

Version: **18.9.5**

This is the Android packaging of the native SA Calculator engine. The calculation core is C++17 and is compiled through the Android NDK/CMake. The Android UI is a dependency-free native Java Activity; there is no JavaScript, HTML, CSS, WebView, or browser runtime.

## Included

- 28 calculator tools from the native engine
- Tool-specific Android forms
- Native C++17 calculation engine
- NDK + CMake integration
- Home / Tools / History / Favorites / Settings
- Persistent history and favorites via Android SharedPreferences
- Compact layout preference
- High-contrast preference
- Graphing engine bridge
- Debug and release Gradle build variants
- GitHub Actions workflow that builds both APK variants
- Clean repository structure

## Requirements

- Android Studio with Android SDK
- JDK 17
- Android SDK Platform 37
- Android Build Tools 36.0.0
- Android NDK 28.2.13676358
- CMake 3.22.1
- Gradle 9.5.0 when building from the command line

Android Gradle Plugin 9.3.0 is used by this project. The Android build system requires the NDK/CMake components for native C++ compilation.

## Android Studio build

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Install the requested SDK/NDK/CMake components if Android Studio prompts you.
4. Select the `app` run configuration.
5. Run on an emulator or USB-connected Android device.
6. For APK: **Build → Generate App Bundles or APKs → Generate APKs**.

## Command-line build

```bash
gradle --no-daemon :app:assembleDebug
gradle --no-daemon :app:assembleRelease
```

Debug output:
`app/build/outputs/apk/debug/app-debug.apk`

Release output is unsigned by default:
`app/build/outputs/apk/release/app-release-unsigned.apk`

## GitHub Actions build

Push the repository to GitHub. The workflow at `.github/workflows/android.yml` automatically installs the Android SDK/NDK/CMake toolchain, builds debug + release APKs, and uploads both APKs as workflow artifacts.

For a manual build, open **Actions → Android APK → Run workflow**.

## Release signing

Do not commit a keystore, passwords, or signing credentials. For a Play Store release, create a private signing key outside the repository and configure GitHub Actions secrets/environment according to your release policy. The included release APK is intentionally unsigned.

## Clean-source guarantee

The Android project contains no `.js`, `.html`, `.css`, WebView, DOM, or browser runtime source. The native calculator core is reused from the verified C++ release and the Android layer is native Java + JNI.
