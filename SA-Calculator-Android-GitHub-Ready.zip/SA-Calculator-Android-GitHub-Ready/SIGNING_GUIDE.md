# Release signing

The repository builds an **unsigned release APK** on purpose. Never commit a keystore, signing password, or upload key to GitHub.

## Android Studio

1. Open the project.
2. Select **Build → Generate Signed Bundle / APK**.
3. Choose **APK** (or Android App Bundle for Play distribution).
4. Create/select a keystore stored outside the repository.
5. Build the `release` variant.

## GitHub Actions

For automated signing, store the keystore and credentials as protected GitHub Actions secrets/environment values and decode/use them only during the release job. Keep signing configuration outside the public source tree.
